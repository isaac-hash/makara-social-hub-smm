<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*----------  Affiliate  ----------*/
$lang["Visits"] = "Visits";
$lang["Registrations"] = "Registrations";
$lang["Referrals"] = "Referrals";
$lang["Conversion_rate"] = "Conversion rate";
$lang["Total_earnings"] = "Total earnings";
$lang["Available_earnings"] = "Available earnings";
$lang["Referral_link"] = "Referral link";
$lang["Minimum_payout"] = "Minimum payout";
$lang["Get_Referral_link"] = "Get Referral link";
$lang["Payout_amount"] = "Payout amount";
$lang["Payout_status"] = "Payout status";
$lang["Payout_amount"] = "Payout amount";