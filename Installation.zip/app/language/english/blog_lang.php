<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang["Blog"] = "Blog";
$lang["we_bring_you_the_best_stories_and_articles_youll_find_tips_on_all_social_networks_growth_and_general_social_media_advice_as_well_as_latest_updates_related_to_our_services"] = "We bring you the best stories and articles. You'll find tips on all Social Networks growth and general social media advice as well as latest updates related to our services.";
$lang["by"] = "by";
$lang["back_to_blog"] = "Back to Blog";
$lang["related_posts"] = "Related Posts";
$lang["last_posts"] = "Last Posts";
$lang["Categories"] = "Categories";
$lang["service_items"] = "Service items";
$lang["back_to_home"] = "Back To Home";