<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-09-28 17:55:22 --> Config Class Initialized
INFO - 2022-09-28 17:55:22 --> Hooks Class Initialized
DEBUG - 2022-09-28 17:55:22 --> UTF-8 Support Enabled
INFO - 2022-09-28 17:55:22 --> Utf8 Class Initialized
INFO - 2022-09-28 17:55:22 --> URI Class Initialized
INFO - 2022-09-28 17:55:22 --> Router Class Initialized
INFO - 2022-09-28 17:55:22 --> Output Class Initialized
INFO - 2022-09-28 17:55:22 --> Security Class Initialized
DEBUG - 2022-09-28 17:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-28 17:55:22 --> CSRF cookie sent
INFO - 2022-09-28 17:55:22 --> CSRF token verified
INFO - 2022-09-28 17:55:22 --> Input Class Initialized
INFO - 2022-09-28 17:55:22 --> Language Class Initialized
INFO - 2022-09-28 17:55:22 --> Language Class Initialized
INFO - 2022-09-28 17:55:22 --> Config Class Initialized
INFO - 2022-09-28 17:55:22 --> Loader Class Initialized
DEBUG - 2022-09-28 17:55:22 --> Config file loaded: D:\laragon\www\smmsp\code\app\config/app_config.php
INFO - 2022-09-28 17:55:22 --> Helper loaded: app_helper
INFO - 2022-09-28 17:55:22 --> Helper loaded: app_array_helper
INFO - 2022-09-28 17:55:22 --> Helper loaded: app_template_helper
INFO - 2022-09-28 17:55:22 --> Helper loaded: common_helper
INFO - 2022-09-28 17:55:22 --> Helper loaded: currency_helper
INFO - 2022-09-28 17:55:22 --> Helper loaded: security_helper
INFO - 2022-09-28 17:55:22 --> Helper loaded: form_helper
INFO - 2022-09-28 17:55:22 --> Helper loaded: url_helper
INFO - 2022-09-28 17:55:22 --> Helper loaded: language_helper
INFO - 2022-09-28 17:55:22 --> Helper loaded: cookie_helper
INFO - 2022-09-28 17:55:22 --> Helper loaded: smmapis_helper
INFO - 2022-09-28 17:55:22 --> Helper loaded: email_helper
INFO - 2022-09-28 17:55:22 --> Helper loaded: file_manager_helper
INFO - 2022-09-28 17:55:22 --> Helper loaded: form_template_helper
INFO - 2022-09-28 17:55:22 --> Helper loaded: partials_helper
INFO - 2022-09-28 17:55:22 --> Helper loaded: validation_helper
INFO - 2022-09-28 17:55:22 --> Helper loaded: user_helper
INFO - 2022-09-28 17:55:22 --> Helper loaded: settings_helper
INFO - 2022-09-28 17:55:22 --> Language file loaded: language/english/common_lang.php
INFO - 2022-09-28 17:55:22 --> Database Driver Class Initialized
INFO - 2022-09-28 17:55:22 --> User Agent Class Initialized
INFO - 2022-09-28 17:55:22 --> Model Class Initialized
INFO - 2022-09-28 17:55:22 --> Model Class Initialized
DEBUG - 2022-09-28 17:55:22 --> Template Class Initialized
INFO - 2022-09-28 17:55:22 --> Session: Class initialized using 'database' driver.
INFO - 2022-09-28 17:55:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2022-09-28 17:55:22 --> Pagination Class Initialized
DEBUG - 2022-09-28 17:55:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2022-09-28 17:55:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2022-09-28 17:55:22 --> Encryption Class Initialized
INFO - 2022-09-28 17:55:22 --> Form Validation Class Initialized
INFO - 2022-09-28 17:55:22 --> Controller Class Initialized
DEBUG - 2022-09-28 17:55:22 --> refill MX_Controller Initialized
DEBUG - 2022-09-28 17:55:22 --> File loaded: D:\laragon\www\smmsp\code\app\modules/refill/models/refill_model.php
INFO - 2022-09-28 17:55:22 --> Model Class Initialized
INFO - 2022-09-28 17:56:06 --> Config Class Initialized
INFO - 2022-09-28 17:56:06 --> Hooks Class Initialized
DEBUG - 2022-09-28 17:56:06 --> UTF-8 Support Enabled
INFO - 2022-09-28 17:56:06 --> Utf8 Class Initialized
INFO - 2022-09-28 17:56:06 --> URI Class Initialized
INFO - 2022-09-28 17:56:06 --> Router Class Initialized
INFO - 2022-09-28 17:56:06 --> Output Class Initialized
INFO - 2022-09-28 17:56:06 --> Security Class Initialized
DEBUG - 2022-09-28 17:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-28 17:56:06 --> CSRF cookie sent
INFO - 2022-09-28 17:56:06 --> Input Class Initialized
INFO - 2022-09-28 17:56:06 --> Language Class Initialized
INFO - 2022-09-28 17:56:06 --> Language Class Initialized
INFO - 2022-09-28 17:56:06 --> Config Class Initialized
INFO - 2022-09-28 17:56:06 --> Loader Class Initialized
DEBUG - 2022-09-28 17:56:06 --> Config file loaded: D:\laragon\www\smmsp\code\app\config/app_config.php
INFO - 2022-09-28 17:56:06 --> Helper loaded: app_helper
INFO - 2022-09-28 17:56:06 --> Helper loaded: app_array_helper
INFO - 2022-09-28 17:56:06 --> Helper loaded: app_template_helper
INFO - 2022-09-28 17:56:06 --> Helper loaded: common_helper
INFO - 2022-09-28 17:56:06 --> Helper loaded: currency_helper
INFO - 2022-09-28 17:56:06 --> Helper loaded: security_helper
INFO - 2022-09-28 17:56:06 --> Helper loaded: form_helper
INFO - 2022-09-28 17:56:06 --> Helper loaded: url_helper
INFO - 2022-09-28 17:56:06 --> Helper loaded: language_helper
INFO - 2022-09-28 17:56:06 --> Helper loaded: cookie_helper
INFO - 2022-09-28 17:56:06 --> Helper loaded: smmapis_helper
INFO - 2022-09-28 17:56:06 --> Helper loaded: email_helper
INFO - 2022-09-28 17:56:06 --> Helper loaded: file_manager_helper
INFO - 2022-09-28 17:56:06 --> Helper loaded: form_template_helper
INFO - 2022-09-28 17:56:06 --> Helper loaded: partials_helper
INFO - 2022-09-28 17:56:06 --> Helper loaded: validation_helper
INFO - 2022-09-28 17:56:06 --> Helper loaded: user_helper
INFO - 2022-09-28 17:56:06 --> Helper loaded: settings_helper
INFO - 2022-09-28 17:56:06 --> Language file loaded: language/english/common_lang.php
INFO - 2022-09-28 17:56:06 --> Database Driver Class Initialized
INFO - 2022-09-28 17:56:06 --> User Agent Class Initialized
INFO - 2022-09-28 17:56:06 --> Model Class Initialized
INFO - 2022-09-28 17:56:06 --> Model Class Initialized
DEBUG - 2022-09-28 17:56:06 --> Template Class Initialized
INFO - 2022-09-28 17:56:06 --> Session: Class initialized using 'database' driver.
INFO - 2022-09-28 17:56:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2022-09-28 17:56:06 --> Pagination Class Initialized
DEBUG - 2022-09-28 17:56:06 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2022-09-28 17:56:06 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2022-09-28 17:56:06 --> Encryption Class Initialized
INFO - 2022-09-28 17:56:06 --> Form Validation Class Initialized
DEBUG - 2022-09-28 17:56:06 --> File loaded: D:\laragon\www\smmsp\code\app\modules/order/config/autoload.php
DEBUG - 2022-09-28 17:56:06 --> File loaded: D:\laragon\www\smmsp\code\app\modules/order/helpers/user_order_helper.php
INFO - 2022-09-28 17:56:06 --> Controller Class Initialized
DEBUG - 2022-09-28 17:56:06 --> File loaded: D:\laragon\www\smmsp\code\app\modules/order/models/order_model.php
INFO - 2022-09-28 17:56:06 --> Model Class Initialized
DEBUG - 2022-09-28 17:56:06 --> order MX_Controller Initialized
DEBUG - 2022-09-28 17:56:06 --> File loaded: D:\laragon\www\smmsp\code\app\modules/order/config/autoload.php
DEBUG - 2022-09-28 17:56:06 --> File loaded: D:\laragon\www\smmsp\code\app\modules/order/helpers/user_order_helper.php
DEBUG - 2022-09-28 17:56:06 --> File already loaded: D:\laragon\www\smmsp\code\app\modules/order/models/order_model.php
INFO - 2022-09-28 17:56:06 --> Model Class Initialized
INFO - 2022-09-28 17:56:06 --> Language file loaded: language/data/en_lang.php
INFO - 2022-09-28 17:56:06 --> Helper loaded: inflector_helper
DEBUG - 2022-09-28 17:56:06 --> File loaded: D:\laragon\www\smmsp\code\app\modules/order/views/logs/child/index.php
DEBUG - 2022-09-28 17:56:06 --> File loaded: D:\laragon\www\smmsp\code\app\modules/order/views/logs/index.php
ERROR - 2022-09-28 17:56:06 --> Could not find the language line "theme_customizer"
ERROR - 2022-09-28 17:56:06 --> Could not find the language line "logout"
ERROR - 2022-09-28 17:56:06 --> Could not find the language line "logout"
ERROR - 2022-09-28 17:56:06 --> Could not find the language line "logout"
ERROR - 2022-09-28 17:56:06 --> Could not find the language line "theme_customizer"
ERROR - 2022-09-28 17:56:06 --> Could not find the language line "daynight_mode"
ERROR - 2022-09-28 17:56:06 --> Could not find the language line "day"
ERROR - 2022-09-28 17:56:06 --> Could not find the language line "night"
ERROR - 2022-09-28 17:56:06 --> Could not find the language line "layout_option"
ERROR - 2022-09-28 17:56:06 --> Could not find the language line "expanded_menu"
ERROR - 2022-09-28 17:56:06 --> Could not find the language line "collapsed_menu"
ERROR - 2022-09-28 17:56:06 --> Could not find the language line "sidebar_color_option"
ERROR - 2022-09-28 17:56:06 --> Could not find the language line "light"
ERROR - 2022-09-28 17:56:06 --> Could not find the language line "dark"
DEBUG - 2022-09-28 17:56:06 --> File loaded: D:\laragon\www\smmsp\code\app\views/layouts/user.php
INFO - 2022-09-28 17:56:06 --> Final output sent to browser
DEBUG - 2022-09-28 17:56:06 --> Total execution time: 0.1116
INFO - 2022-09-28 17:56:35 --> Config Class Initialized
INFO - 2022-09-28 17:56:35 --> Hooks Class Initialized
DEBUG - 2022-09-28 17:56:35 --> UTF-8 Support Enabled
INFO - 2022-09-28 17:56:35 --> Utf8 Class Initialized
INFO - 2022-09-28 17:56:35 --> URI Class Initialized
INFO - 2022-09-28 17:56:35 --> Router Class Initialized
INFO - 2022-09-28 17:56:35 --> Output Class Initialized
INFO - 2022-09-28 17:56:35 --> Security Class Initialized
DEBUG - 2022-09-28 17:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-28 17:56:35 --> CSRF cookie sent
INFO - 2022-09-28 17:56:35 --> CSRF token verified
INFO - 2022-09-28 17:56:35 --> Input Class Initialized
INFO - 2022-09-28 17:56:35 --> Language Class Initialized
INFO - 2022-09-28 17:56:35 --> Language Class Initialized
INFO - 2022-09-28 17:56:35 --> Config Class Initialized
INFO - 2022-09-28 17:56:35 --> Loader Class Initialized
DEBUG - 2022-09-28 17:56:35 --> Config file loaded: D:\laragon\www\smmsp\code\app\config/app_config.php
INFO - 2022-09-28 17:56:35 --> Helper loaded: app_helper
INFO - 2022-09-28 17:56:35 --> Helper loaded: app_array_helper
INFO - 2022-09-28 17:56:35 --> Helper loaded: app_template_helper
INFO - 2022-09-28 17:56:35 --> Helper loaded: common_helper
INFO - 2022-09-28 17:56:35 --> Helper loaded: currency_helper
INFO - 2022-09-28 17:56:35 --> Helper loaded: security_helper
INFO - 2022-09-28 17:56:35 --> Helper loaded: form_helper
INFO - 2022-09-28 17:56:35 --> Helper loaded: url_helper
INFO - 2022-09-28 17:56:35 --> Helper loaded: language_helper
INFO - 2022-09-28 17:56:35 --> Helper loaded: cookie_helper
INFO - 2022-09-28 17:56:35 --> Helper loaded: smmapis_helper
INFO - 2022-09-28 17:56:35 --> Helper loaded: email_helper
INFO - 2022-09-28 17:56:35 --> Helper loaded: file_manager_helper
INFO - 2022-09-28 17:56:35 --> Helper loaded: form_template_helper
INFO - 2022-09-28 17:56:35 --> Helper loaded: partials_helper
INFO - 2022-09-28 17:56:35 --> Helper loaded: validation_helper
INFO - 2022-09-28 17:56:35 --> Helper loaded: user_helper
INFO - 2022-09-28 17:56:35 --> Helper loaded: settings_helper
INFO - 2022-09-28 17:56:35 --> Language file loaded: language/english/common_lang.php
INFO - 2022-09-28 17:56:35 --> Database Driver Class Initialized
INFO - 2022-09-28 17:56:35 --> User Agent Class Initialized
INFO - 2022-09-28 17:56:35 --> Model Class Initialized
INFO - 2022-09-28 17:56:35 --> Model Class Initialized
DEBUG - 2022-09-28 17:56:35 --> Template Class Initialized
INFO - 2022-09-28 17:56:35 --> Session: Class initialized using 'database' driver.
INFO - 2022-09-28 17:56:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2022-09-28 17:56:35 --> Pagination Class Initialized
DEBUG - 2022-09-28 17:56:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2022-09-28 17:56:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2022-09-28 17:56:35 --> Encryption Class Initialized
INFO - 2022-09-28 17:56:35 --> Form Validation Class Initialized
INFO - 2022-09-28 17:56:35 --> Controller Class Initialized
DEBUG - 2022-09-28 17:56:35 --> refill MX_Controller Initialized
DEBUG - 2022-09-28 17:56:35 --> File loaded: D:\laragon\www\smmsp\code\app\modules/refill/models/refill_model.php
INFO - 2022-09-28 17:56:35 --> Model Class Initialized
